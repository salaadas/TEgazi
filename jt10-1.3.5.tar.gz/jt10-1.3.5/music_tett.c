#define static 
#define z music_tett_Data 
#define Values music_tett 
int Values[]={1276 /* size */, 3743, /* rows */
	199 /* loop */, 134 /* xor */, 7, /* compr */
	10  /* depf */, 8 /* len */,
	64 /* count */, 172 /* roll */,
	300 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"+l=6*mM*JlmZmom+mom)omm5lmm=nmmUA2e9\\]N]cTYOUam:*2[K>RJ)BZ"
"65XJ><R6=OB=daZ)[X+J`m)*gm5*fm=*nmM*bmm*Zmm+JM_>=CLXnUcc:*J:Tm>mJL<6*3*`5f=U"
"U)+J(NlcnM2)B*YYK*2+>mBl=6)0*`+f=RM==5(J6nnacmJ8ZZKZ2K)IK456)4<2)?N248`:[nZK"
"3[H)F845^54<N=?NZLfb:>nXKH+R:=5(*7(o5`mJH[Z+>JK)aD>50Te<B=DO*:AbZ33X+CRK)[`3"
"5`:;<:[CN*:=c:;mX+adP)FN45LXB<*RUNRBncZ6A[+0\\V)ad450Te<B=DORRoc:^8XK3DK)FN4"
"5TB4<*RfNRRecJOAg+0<I)=C>5*f?<F>lNJo6c*7EXKOaK)7YA5^5Q<FfoN*:1cZ6A[+0<I)*0?5"
"0`I<Be>OBHGbZ9Pf+*oK)d9=5de4<ZLBNRBLcJo:Y+79^)d9>50@M<*RWNR)7c*7U[+a3T)7_85^"
"A1XnM2*2b*J@g+7aW)ad)5^U8<RB^O2D=3ZmK*bm)*fm5l]m=b]N5Ao:*^:^m)+*)5X*8<6)TZ@o"
":*^*Qm)+*)5ZJ;<6)TNRBVSg`K*:KDm5(*4<J+1N2)Nb*QZYKH+Q)aD>PD=6*0R`m:*ZZ+>BK)CJ"
">5FH4<ZLGORoXb:^4Y+WgV)?Zm5BRm=^JmM:KmmZmmmKmmm)mmm5lMN)nM2*>4e`K*Z7NmblS_L2"
"*NKd=_MAQ5(*E^oAaMd`K*bWCmYl=n4>*Ao:*V*^MBm[D=6*06a=dmKB*I)W:350TB<N20N:+>+d"
"=^m)0d15^>5<V<DNRBncZR_[+ZIK)0D)5VQ7<^*V6a=dmK90T)H;>\\D=6*0b`egm+=fH)OR)5n1"
"C<:[;LBHCb*7U[+GNI)=3G5RbB<>[oNJHYbZ4oZ+04^)9^B5RBM<>[>NJHeRe`K*ZWLmol=J*2N:"
"*0b*)Z*]g)+*+nl=6*4NR6@be`K*:VMmml=b)7NB2<bZS5)Zg)+J7*m+lMRBZb*Z)I_MAm5VGL<f"
"Q?N:*XbJMGX+E`J)(:+5056<2*7N2)BbJR[Z+aJK)>M3cD=6*0Va=emK)SI)a4(5LI2<*nJN:>Bb"
"*R2K_m)+J+5Rl)<2*7NB`=bJ*FZ+alW)=l456J4<nV>NJH_cZ6YZ+0<I)9^?5RBW<>[BNJHWcZ6U"
"f+0DP)9>)5RbU<>[BNJHAbJJMZ+0DS)9>)5RBg<:a?N2[8cJHSZK)aJ)04(58>4<RB]O2[^cJHSb"
"+>I+";
