#define static 
#define z music_none_Data 
#define Values music_none 
int Values[]={9 /* size */, 1, /* rows */
	0 /* loop */, 2 /* xor */, 7, /* compr */
	7  /* depf */, 8 /* len */,
	64 /* count */, 40 /* roll */,
	64 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"+d)f-b5Z5";
