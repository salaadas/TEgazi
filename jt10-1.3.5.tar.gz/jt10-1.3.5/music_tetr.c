#define static 
#define z music_tetr_Data 
#define Values music_tetr 
int Values[]={2129 /* size */, 3456, /* rows */
	0 /* loop */, 134 /* xor */, 7, /* compr */
	10  /* depf */, 8 /* len */,
	64 /* count */, 172 /* roll */,
	300 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"+l=6*mM*JlmZmoMJm*mR*:KJ0(W4P;FQRR;gI`m:*nZ0JG2QHDS_@Ng`0`G"
"oQl=6*=N*4nJ3*96T;>gB<XNoJ+ZZ+Zbm)Jfm5*Xm=*ZmM*lWbJ+2[+bUK)L=)5*L4<*mBN*4lm*"
"2om+2nm)Znm5Jmm=*m39bc:*Z7KM(m6l=*4mM*Vlm*:lm+*lm)*=3WL<6*6G`]fMSm;=IL4o>`Cf"
"mRm)?J+TL>oB`[fISM9mRL:oJ`+g)PMFmPL<6*^R`Eg]Pm)d*+52J2:oI`5gm+PJJ)6:6Tl=B44N"
"R6:b:VZ:RU)+*2Kl)o5`mZ+BZKFeJ)*I+5PO)<>?4N2b?b*LF[+(cK)n)+52J<4o=`Mf=RU)+*7J"
"l+o)`m*JK6Q5D=^LBoZ`UgMQUD=_L@of`]gmQUE=]LLon`mgM^UB=[LHo6a=d]^U)+*1XlWo1amJ"
"?:Z+(2HBm[lIoMJ02b*+6[Qm)TK+50+6<b56NJ*>RgMQM@=5(*:Ro9aUdmK4J+N=5(J6ZoIa=eYK"
"*2KNmcleoN2**Cem\\mOm5b+7<R*EJa5e=\\m)6(45*]:<6(N@`ef]Sm)m==5bK:2n9bUZm+Z*^)"
"1\\+5nA)2o:`Kf)S58mVl=Rb4NJYGb*>*XK(e*F=RL:oJ`+g=Pm)*I65n*48oV`3g9PUFmSlEo^`"
"CgYPUGmQl=RX4N*LVbJ:Y*^5B=ZLJo*a5dmK>dJ)c0)5(34<6_>NZ)Fb*4BZ+4*K@=gLPoFaSdM_"
"m);W+5ZA><fcVNac:*VZ_mAm5PO4<Fg>NJD2b*+6+^MBmZl=:bBN*Zba*+BZ+)IK)*435F*><*B8"
"NRn;b*J;Z+(ZJ@mgl=*BBN:1nb:)AZ+JVJ)6J+5>8)<:*4^`Mg]QU)+:(\\lOoMR\\B2dYK*2KBm"
"[l=fL>>ac:*Nf+ZJK)_5)5J67<R*]b`eg]Qm)NH(YlUoMJRZZdYK*bR)F?)5R(7^oAa5eYK*R(Nm"
"bl=b+4N2a?bJ6BZKXe*O=5(JOn^aCdYPU;=UL<Kn+c)X5V=2I:4GoS`9gUP=GIP4=Z*4bcYYUU=="
"ML4o>L*)V2fER]:MKl(?4@n*>B:Q]DM_l@og@^gb+>Z)?M@lfnSc9YRT[)JK+Tl>oC`YfUS;9I5Z"
"*=bn[cIY5U=<IN4=*34J`)g5P=FMR4;?L*)nb*PJ[+Jcm)*dm5*Xm=*nmM*bmm*Zmm+Jeg):<)5b"
"N)lnocaYeU]=IM4=*m>N:(>b*>2UR=;MHl6o3@Ffb+leJ;MIl4o?`AfbR[)n]+Vl<6*3:@Vfb+)Z"
"J)BJ(V43?LZ4>b*_ZZ+VJK)Z*A5R74<Z>>NJZ3b*+B:R[:I5*^m=*BmM*Jo\\fES]8MWl0?D@n*m"
"AJS=9MTl>oC@ffb+beJ9M5(J6<?L@nJ+BZ+>:K9IU4=B)4NJm3b*+BJR;;I5:((<:*4F@^fb+L:H"
")ZJ25*)B<*32J`)g5P=FMR4;?LJm?2gEP]FMSl8?T@n*nAJU])+:(L4o>LJ+JZYRU[)`\\+Cl<6*"
"3VC>Yb+TUJ)6J+N4c>LZ4>b*8RZ+B*6:MJl*o+`)f2R[)n]+5B*)<J54^ca:*VZT[?I5J64<:a>N"
"*b?bJ:B:U])+*7O4a>dC6X>V;2M5(*_J>(CnJEZg+Z2fBM[lHo7a1dB^[)3V+dl^oCaYdU_;AI5P"
"2)XoWa1eE\\]NIc4=684Ja)e5\\=NMb4[?LRW>b*>J[+VJ+@MflRo;aId2_[)ZJ05*)F<:*4NZG>"
"b:]KZ+JKY)67)al<6*3^ANeb+J+g)*dm5*bm=*ZmM*Jmm*ZYZ+TUJ)6:\\c4Y?TAn*YYZ+<EK)6Z"
"(:4K>(Cnde_]AMel\\?LAn*42K^=CMXlVo3AFdb+B:H)V=)5JM4Jo+a)d5^=BIZ4=Zm4NJ5Fb*Ga"
"Z+d:K)Ng7c4Y?TAn*3*[+J;\\)264:4K>\\`a:*:[P[GIQ4AoO2*8RgBQ[)V=)5*>X<:*4:AVdb+"
"*)e)*I65*>A<RE>NJA;b**Ig+(:(@If4QoO2*8RdB_[)R1)`lfoSa9eU\\;OI5JC3<R(4NJY?ZdU"
"_=AMdl^?@An*PA*\\])+Z;5R(4<Z4>>aa:*JY^[CIY4=Z36JA6eb+<EH)V))al<6*5OJ0JBeb\\["
")[]+ol<6*GfA^eb+8*HLIo4=6m4naa:*^)";
