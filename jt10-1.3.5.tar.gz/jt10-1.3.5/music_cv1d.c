#define static 
#define z music_cv1d_Data 
#define Values music_cv1d 
int Values[]={3095 /* size */, 4143, /* rows */
	1411 /* loop */, 134 /* xor */, 7, /* compr */
	10  /* depf */, 8 /* len */,
	64 /* count */, 172 /* roll */,
	300 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"d<_O@afd__a)7*0d\\C\\YNUc<Ym)0J(*mB<YNUcmK*ZJ)0J55V+F<J(fN2"
"=0`JRNf+8@V)YF+5605=6FYLB\\nb:S7fK`)P):[Q5:1=<J(mM*I:c:ZeX+gmU))=I5DM=<:+LN2"
"e;c*RRg+n*f)Qm)5Jm(<6l=NB6RbZP<X+LbK)\\;45J(_<60oN:F0a:[m[KKXU)67d5>lm=bl\\N"
"2Ilm:>l1Z=JM56fm=^lmM:Y9o*oEZKnEK)Pm0+l=6*UNcc:*NZWm1mCLXnVc3Y9Tm)+:+NLbnZcK"
"Y)Um)+:+LL<6*QcceYm+7:H)G:6Ll=6*7N2FF:YYK*J?""?m@l=R*NRc;Y9TR)+:(NH<6*3b3`:*"
"f[+K8^)+GQ501)<2*6NB\\Nb*7BZK:_J)7:(5LG)<R*<NbE?bJ(bZ+FJH)X*75J(F<>XFNZ8?b*R"
"BcK\\eJ)(*+5H36<F*5NJW:bJ(B[+FbQ)+M(5*0(<Fo4N*R2b*R>cKM0K1m5lC7FoR`;gIP5Gm5("
"J(<:+LN278c:FJ[KLbW)*_(TL>oB`[fISm)+J+5P*0<:+VOBVGRY9UU<=OL`nM2*0bJ+CY+F:_)^"
"6L5X_(<bA6NJ*Lb*7*+U2<;NHb6[cm*e9Z+(2+<m5LJ6<R*4NRl?bJ(nZ+CR*=;LHn6c3`J@A*R5"
":=JL*o*`m:*FZ+=:K):K;54c(<JX6NJ*FZYm+22K)0J+5@M)<R*=NB40*F6R2:;JH<N346`3f9RU"
":=Kl=6*4N:0Vb:FbY+c;T))G:52PR=NNCNJ(<n*(U[+0b\\)GL65Lm(<6*7N:+^>Y9TU>=CLXnM2"
"*0bJ(2bTU?=ALdn^cm:*F:UU<=OL`nfcm:*FZK*G\\)(`m56fl=Z2]LRe32YIU2=;LHn6O:V?:gI"
"P5G=PLFoM2*0bJ?QZ+0:H*m5(J^@og@^gCQgD]_TAOe@]gMQm)0*7^lB?X`Vg0QEDY^\\C_Y`Ugm"
"+FbJ)+*(_dAoe`]gMQmEM]4MOl@ogaQcEe5(*6L_m`mgmQmEm5J(1<679f`o:*V:Qg)+:(_<=6*3"
"Nb12b*+BZK:[J)H8B5(7J<*0JL2RTaZ>8[KeFK)(*7bD[oHAl:*Z*\\ANabl=6*>NAoda_c)+J7e"
"\\]_Mamdm_MAQdL_?M2*BZd__OAm5(*4P_Da_dnK**V@egdQoM2**c*Rnm+JPcBU[DIo4a?dA^cB"
"e[dIo5a5d3^GB]ZLKo(A4d?^OBmZl=:+N6A=dM^MGUPDGoP`GgQPCGePdGoQ`]gCQgD]_L=:m4Nb"
"2FbJ*RZK_ZH)Z;(5<(0<n`0N*9FbZA*[KK]*@UfDSoL2*BJd>_A@afl=6*1N:FRJdnK*BH)6;)5H"
"H)R_L2*TJdcK*RI))7>560J<6F*O*R:1e@\\eNY5(*4XOUA=eM\\mNm5dN0<n`7NRf1Jd0_E@YfT"
"=^N4n@ogaQcEY]TMOm@mgmQmEm5R*0B_X`WgnK*J+De^dCoY`UgmK`EK)Z](5JHA<R7=R@GgQPCG"
"Y5Le(Foe@_gAQcDY_TAOM2G12d@^eBY[T=*]4NR(>b*7bZ+9UH)5;+54*)<f67NB*0b:=:[KRBV)"
"A[)560C<>FmNJRTl*eGZK+JH)EO+5Jf(<>*FNJF12dnK*2KB]5(J6H_L2*TbJ6mZK3\\JOQaLe?M"
"2*@Beo\\oOmala?M2*8ReaK*2K)VP55n7=<Z10n`o:*VZQg)+Z65nn5<nc7NJDRBeaK*:KOQ5(J6"
"<*\\1N2+NbZ<EZK[dI)aW(_L=6*3f@o:*>[K)4H)C?+5P70XoL2*82e`K*2K@QgLQ?M2*\\RdO_o"
"@mgl=6dCNRe1bZ7cZ+9d*N]5(J3Z_L2*T*ecK*bV)+0O56fm=2RmM:9?*emK*2K)m=65T`4<NB;N"
"J2A2emKKfK);S+50_7<b@9N*eFBecK*RIOm5(J6HO4A?dA^eB][TIO5A=dM^MBUZDKo(a7d1^CBe"
"ZdKo)am*7Z;Jm)+:>Wd0oG@^fCSg8]WT1OE`\\f<P?FMR4;OH@7g1PCFeR\\;_Q`o:*VJPg)+:(5"
"<K)0_E`]fm+7RV)+*(Wd1oE`m*7f[+RbK)W[6PdFoS@FgSPGG]PTGOQ`DglK:;+9]5(J6>_L2*8Z"
"fUS;9UTD?o@@df^SA9aTl?oMB+>bJ(n[K**+9aTl?oMJ(`b*F6X+KX[)+g^5`1=<2*F:AWd1_c)+"
"*)f\\S_9am:*ZZ^gC]YT=6*D>aLdl^mCmYlW_0aGdnK*J+CeXdWoM2*B2d@^eBY5(*4HO5A=dM^m"
"Bm5dE7<2X5J@5g=Pm)G`+Pd=6*9R`Eg]Pm)JHJIl4?<`Nf`Re;YI\\5_M2*TBfmRm;m5*Pm=*FQ>"
"`Mf]PGG]PTG?Q@Dgo+QIJ)0*0Pl1_D`_fNSc)SM+Wl=f)0f@_gAQcDY_TAOe@]gmK*JK)AK75JI6"
"<N6FNB*Fb:FRZ+AUJ)Q^+5B7)<*50NB*FbJLnZKC*H)g0+5JK4<f*;B@XfWS_)bM+5(J6>?A`df<"
"P3FERd<2[7N2*8*g>PAFaST8OW@1gEP[FUSD9oL2*82gNPaFa540C<2FlN2R*`*:SFQe)+Z6_D=6"
"*3BAgdQ_c)+*)d\\__Aaed]_m)A<7bD=6*4Ja7e>\\A@Q5(*)Ro8ATdoQg)+J+]LM?m`l*7:+Qg)"
"+*6^LC?Y`lJ;NZKW*+Nm5(*(<*7cN:1@:g`K*Z*G]PTGOMJA:RgAQcDe[D=6*46a?dN^a)F*7dD="
"6*:Bagd^_a)5[+5@H6<N\\4N20ZcZDfZ+K(T))W;520U=Bn7NB*RbJdE*QGD]^T=6*DZ`Tg<QMDm"
"^l=bf=NBWSbJdE:\\e)+*6cTYOUAMeaK**HOYa\\e_eAl:*V:]e)+:(RD;oH@l:*B+PAFaRl;oI`"
"mJ]NY+Vc+N]5(*2Z?Ia4el+@KHOY5(*7<n10B@gfQSc)+J7T\\?_A`ef]Sm)mX?5<^5^oL2*JZd^"
"_AAa5P70X?M2*8bZNS:Se8YW\\=6*EF@]fMSm8mUL=?M`l:*N[So9mUl=oU`l:*>;Pc)+Z6SL=6*"
"9V@o:*NXK*_\\)(`m56fm=^S7V`m:*V:PgF]5RD08?U@<gNPaFaSl9oU`m*R`+Qa)+Z65VG0BoL2"
"*TJg`K*R)Dm5(J6<2X7NZK1bJ(B(";
