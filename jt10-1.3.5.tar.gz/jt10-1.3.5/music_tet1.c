#define static 
#define z music_tet1_Data 
#define Values music_tet1 
int Values[]={1299 /* size */, 2256, /* rows */
	0 /* loop */, 134 /* xor */, 7, /* compr */
	10  /* depf */, 8 /* len */,
	64 /* count */, 172 /* roll */,
	510 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"+l=6*ERa:eK\\1OE`<gOPaDe_\\OOa`l=6*INZ7b`JEnm+V`m)Xbm5fam=Z"
"[mM:]mm*5Aa+b5T)T*15b(\\<*nX>OB`ZfIS59]TL?oN`cfgSQ9m=6*INZ7Nc*3J9Jm*mHL<6*;2"
"`Ef]RM;m[L<6*36am:*^:UU)+Z6Olanec]Ym+EZHBm[l=Z7^NZ1VKfYK*2(8mVl3o9`MdYK*2KCm"
"5(J4nnN2*TZY]UM=mLl=*)D6`c:*>;Rm:mKl)oMZ1ZbJ4K[+5[H)fW65f2B<J;\\N:IJc*4S[^mC"
"mWL<6*9F`]fMSm8mgL<6*3Fam:*^*RU)+Z6Jl+o)`5fm+EZH@mgl=oN2*HbfmSm9mUl_oN2*8Zdm"
"K*RK)2745J+G<*S0_cc:*>[Tm?mAlenMJE>`*gcg+egW)^Q15NEB<BE\\NZOSb*a`X+e7T)^Q45N"
"EB<Z\\8NZOC`JOcX+eWH)d755NEE<J`ZNZOOc*g+Y+dWW)\\1=5NL(<*a:N:3Kb*m+;PU)+Z(Sl9"
"oU`=g]PU)+:(PlGoQ`EgMQU)+Z(_lAoe`]g]QU)+Z(\\lOoa`eg=^U)+Z(ZlKo)a5dm+[DK)V_+5"
"JL5<B^0N*CKbJ):g+M7I)6J9+l=6*EFAn:*V:_m)+Z25N+\\<b7ZBAn:*VJ_m)+:35J+E<Z1LO*S"
"n`J4cX+V(4NI5(J6ZoM2*4cJ1bH\\[)+:(`l=6*WN*4Nc*V`g+L[Q)FUE5ZL4=Re\\NZEKc*5aX+"
"dgW)\\1]5bBB<R`\\N*aKcJaXg+MgQ)VJ;+5=6*16n=bMZmJmm4=6*1namem]mMmo4=6*1fa]eM]"
"mLmn4=6*1ZaUe=]MLm5f85X?L2*D2emK*BT)Z](5F2c<nmB6b=ZMZ[)+:(+m=6*1NZ(FbJ(ZZ+;J"
"K)\\*25N((l?L2*Xbem]mMmml=b(VN*72JebK*2+Lm5(J4`?L2*8RemK*BK)DJ(5F*4<2(>NJ+Nb"
"*1B[+`:K)0J65b)5<*)@NZG22ebK*2KNm5(J7f?L2*8:emK*RK)BJ(5F*4<:(<NZ7nb*F:Z+L+T)"
"d7;5Z1B<:@BN:4O;bbK*B(Km(m7l1nm*@`Z+(:K)^1;5bB0<Z2BNJ8BbJaHX+W[K)6*(5V4><bg@"
"NJ*RbJH9X+VeI)b<+5*A><Z\\DNZOc`*89Z+FgH)`\\452*1<*mBNZO_b*a`X+<4I)FU;52:><R^"
"BNZOOcJ4H[+2gR)dW15Z1B<B@DfA^eb+CfR)\\Q(5F*5<B_\\N*)NcJN)[+\\7H)2?65274<:c6B"
"An:*VJ_MAmdl_oEAn:*^:_m@mglQoANn:*>K[m)+ZQ*";
