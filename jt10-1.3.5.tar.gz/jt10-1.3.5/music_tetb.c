#define static 
#define z music_tetb_Data 
#define Values music_tetb 
int Values[]={2701 /* size */, 4189, /* rows */
	1 /* loop */, 134 /* xor */, 7, /* compr */
	10  /* depf */, 8 /* len */,
	64 /* count */, 172 /* roll */,
	250 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"+l=6*1>OB`[fQSU9m=6*:NR(2B``+1ZV)QZ05\\H1<6+^NZG*`ZQbdK>[R)"
"ZIM5`P[<NKd>OB`[fQ):b+9==Z6<NZ6;bJ7*Y+[VK)O;(54W7<B+QNB:Hc:AFd+f<T)ZY]5*]d<f"
"G]N*bmaZQZg+bCP)O7T5J5^<*L+OB>)cZ70fKLbm)nfm5d[m=RYmMbm=9eJ\\3OI`TgOQAEemK*b"
"K)D::5\\HQ<f4)L*Llm*bOoK)\\J)4>65J*1<^(QNJ7@cZ3^8JM;=5(*66o1`=dYK*bJBm[lanN2"
"*:RYMUm)G*([LHo5aUfYK**+8mVlUoN2*:Bdm^M==5(J)nnacm:7^ZKJBKD=5(*6@oe`5YYK**+>"
"mBl=B+1N::DbJ*^Z+12V)\\H=5L7K<b0dNRQXBYYK**K?mAl=fG1NZYDbJNSZ+_+^)]H75`Pd<ZJ"
"?NRQ6`:H[XKB0S))X?5N7A<Vd(ORQ@a:@]ZK\\P_)>b(5`Pd<*_BN:E)c*aQf+E+U)](:5N7A<n0"
"(OBo5CYYK**K?mAl=fG1NZ`EbZN_ZK61W)@9<5BZM<fGWOR+\\`*bCY+gLK:=5(*6(oM2*BbJcLY"
"+^*V)E[G5LW1<fGgO2_Ab:EKg+ZAW)_+B5JU;<f*DN`c:*JZSm)+J2PL<6*2R`m:*6XK@MK)(:9"
"\\L<6*2b`m:*68PU)+*(Sl=6*HN:E71dYK**KBm[lanN2*:RYMUm)DZ(5BKFHo5aMfYK**K;mIlU"
"oN2*:Bdm^M==5(*6nnacmJ7^Z+DJW)]H55N7A<*=<Nb(E*YYK**+>mBl=fH1NJ7TbZ0J[K\\PP)L"
"g(5`Pd<*L?N2TBc:HSfKQbP)gD45DA:(oN2*:2fmK*:V)*=1DL<6*8Bcm:*N;Jm)+Z(gT=6*5Fam"
":*ZZK0*K)DJ)dT=6*2Bam:*^ZK0R(AmYT=6*2>am:*ZZ+1BKBY5(*6HoM2*BRfnK**K8m5(J1<b0"
"*ObG*`JQBYKE;R)6Y258^A<6@1NZlPb:E_d+4^K)OG958^G<69+OB:Pc*[VYKf<V)1]75`Pa<bG3"
"NRQ@a*f<XK\\PP)a045fGD<Zl+O*_+c:@af+E+R)]H:5`0^<VBLN:ANcJcLY+4^H)OGA5\\JT<NX"
"DNZ(nbJFeZSc)+*(Ul=6*>Nb0Rc*D>XKQbP)]X75`P`<>g?NRQZ`ZNc[+WQK)JU75^*D<*=+OR+^"
":gnK**+Gm5(*;@?M2*:RgmK*26BY5(*6JoM2*6c:bMZ+B*K)eZ+5^*4<F+5*A4d=^m)^]75@J0<b"
"0Qf`egnK**+Em5(*^P?M2*:RdmK*JK)D*?5(H4^?M2*:ZdmK*JK)DJ:5LW0<:>(OBo<Bdn^cCm5("
"*4<B+LNB74c:ESfK=QK)OGA5*=1<69^N2[(`ZGNg+ZIK)*m05B;1<f*DNb0DcJ2Z8JmJI+5)<4nm"
":*NZK7:+KI(57<0NFb]Zm)A:+m4m?lAnem]m):Z(5@+)<B+7N:*>RebK*2KMI5^*7<F+6fam:*BZ"
"K7BK)KJ+5dJ(b?XAVe2];Lmnl=B(7RAn:*JJ\\m)+*)S4=6*2V`m:*ZZ+ECV)]H+5nW(<R?2N29L"
"bZQRZ+HCK)\\X+5L7(<^*2NZG:bZQBZ+ESJ)]X(5N79<fG2NZ;DbJU^ZK\\@K)8g(5`P7<F?1N:P"
"0bJQGZK\\`V)`D+5:1)<2*7N:+FbJXFZ+)8H)1B75LW6<fG[NJ+Eb:E7Y+4^K)Og154*62<8NVb2"
"[m)+Z+45=6*0NZ(Db*1^ZK__H):a(5@8(<:*5NZN1c*+NZ+SXH)OW)5L73<b0<NRB:bJQbZK_OH)"
"eR)5LW7<R`;NJO;bJREZK\\0U)]H75`0F<B\\1NRQ@a*)\\ZK\\`W)Ta65T`7<RQGNBE_bJ\\P[K"
"f4V)0E65*l4<VdLN*_1b:@AZ+flH)S_45fG1<b32NZG:bZ]JZ+V4H)\\H)5`C;<n00NZG0bZQVYK"
"\\0V)JU754^7<*l7NZ_?b:Ec[KE+K)<L+5:1)<VK7NB+DbJ+C[KfdK)Og>5Lf7<fG]NJ+]c:Y9ZK"
")ZK)`>)5`*7<bg6N:^3bZ>b:[[)+J+5TM)<V63NJX1Zb][m)O:+7m1lM:5>b:WMJZMKm5N*4<2[5"
"NJV=b*MOZK_oJ)]2(o4aoea=ebK*JJNmcl=*c5NR)LbJ<NZK++K)T+)5N75<n0=N*LL:b]ZmVI5("
"*(8lUn5cbK*J*Vm2m=:>7BNfb][m)oH)5N74<n0=N28NbJVJZ+_[K)^J(5J55<fa2N*0NbZoNZK4"
"(K)4F05T47<VB9N:]`bZ9SZ+_CH)3T75`*7<>2ORNn:*:JXMWm5214<FD2NJ^8bJN[ZKc(V)ZB55"
"n[)<*I?ZAVeb+InJ)DG)5^*2<VO4nAn*JHZKDIK)DZ+5PJ)b?XaUem+FlJ)``+5T:6<B+9namemK"
"9lJHI54b)<RZ5NR(BbJ7RZ+<X*VI5f@)0lEnm:;MZ+1JK)GZ+751lEnm:S@ZKd\\J)(*25fT)<Fd"
"6N:*(c*Q@Z+7]J)(*954O)<B*C6n=bm+nBK)8^+5>*5foM2*^b*HOZK)*)Km(m=^=1^An:*>[\\m"
")+Z75N7@<>0?N2E^b:HWZK6ZHMmml=*Q2NBl;b*^`Z+5?K)QZ)5`P@<n0INRQRCem\\m)\\c(58>"
"1<JFKNB:Gb:+?[+)0I)+[6o4=VU1NB>AbZNc[KdRK)\\805L78<FO1NBA+cJn\\ZK9LK)(:245=6"
"*2NbmGbJ(:6";
