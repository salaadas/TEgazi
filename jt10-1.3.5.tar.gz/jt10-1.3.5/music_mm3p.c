#define static 
#define z music_mm3p_Data 
#define Values music_mm3p 
int Values[]={914 /* size */, 1024, /* rows */
	256 /* loop */, 134 /* xor */, 7, /* compr */
	10  /* depf */, 8 /* len */,
	64 /* count */, 172 /* roll */,
	320 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"+l=6*mM*JlmZmom+mom*m+l)n5b=Z=VU)+*):l=6*0N*)ZJXYK*J+0m5(*7"
"<J+BFcc:*Z:Wm)+J(5Z*>\\nN2*BbXmK*:K)B*4CL<6*>Vcm:*RZ+>*I)J+>5*4J<V=2N*UJ:XYK"
"*R*3m8l=*BmM*Zlm**)BJm*mfTR?8AVd2_;@Uf<S_8AWd0_E@]fLS?9ATd?_A@efdS_9AUd=_M@m"
"5Z*>T?""?ANdb^[CIY<UO<AOd`^gC]YLUo<ALdn^aCeY\\U_=AMdl^mCmYl=J+Bn@`gbQ[EI]4MO"
"l`ng`QgEQ]LMol`ognQcEe]\\MOm@mglQoEm]lMoM*)Zb*BFY+XBK):)(bTZ?L2*<*e3\\9NQbD["
"_Ha7ea+f+T)BF+52J2<V80N*68b*=OZ+V(K)J665J36<J+BN*3Jb*KKZ+>*I)*D+52^3<J+BN*VJ"
"b*KKZ+>*I)J+:5*^T<JS9NB*:b*Jom+*aR*m+l[oJa)e5\\=NMb4[?Ha6e3\\9NQbD[_Ha7e1\\c"
"E=]lLoo@ngbQYEU]<=J+BBa[dU_=AMdl^?@AfdS_9AUdD__@AgdQ_EAY5Z*:Ro:aId5_=@Mf4S?8"
"aVd3_9@QfDS_8aWd1_c)B*25*I@<:41N*@:BeY\\]OMaldo_ANeb\\YOUa<e_\\AOe`\\eO]aTao"
"faQeE]]LMo4a?da^eC]YLQoDa_da_eA]cLYoTaOea\\eO]oLaol=J+ONJ*Hb::RZ+ZRJ)V[(5Z)2"
"To>aAde^]CMY4U?<a>e9\\]NMclXoWA>eB\\Y)R7(5ZJ0<:B1n`cgeQ])(D+5Z*><*B7NJZDb*4*"
"X+:(H)B*25*)B<J::N*l:b*D([+2)HOYaTeO]aLeo\\oOaal=*)ONJ*Bb*YO:\\UNMc4eo^aAeB"
"\\UN95Z32<JS2N*@Kb*HKZ+67H)Z:)5*^O=*Zl*";
