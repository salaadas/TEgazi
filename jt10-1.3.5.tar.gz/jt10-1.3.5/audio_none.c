#ifdef DRIVER_NONE

#define ARCH_esd_audio_open
int esd_audio_open()
{
    return -1;
}

#endif
