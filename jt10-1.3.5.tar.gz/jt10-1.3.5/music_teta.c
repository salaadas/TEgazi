#define static 
#define z music_teta_Data 
#define Values music_teta 
int Values[]={985 /* size */, 1619, /* rows */
	0 /* loop */, 234 /* xor */, 99, /* compr */
	10  /* depf */, 8 /* len */,
	64 /* count */, 153 /* roll */,
	300 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"p=JJsX/q[t!)+DY.uZ,-Q]D2)2 p#HVPP2JvA2Buq2ROs22[;22 #R$V@P_"
"q?J;J'&;sKpC2S=B<OMsA;'2(RDBVvSwG<.9ROu#s/* pCq#=P<BuuKXO[#C(* pCqT=N<V9X_sW"
"s)RG2V su[<OMsAS$B.2 #sHVpuAuFNOOuDKXO#s&[YPP [VqVDStC<BU_[[/q/C(2A2T=^<OMsA"
"+$R.2 SwvVpOuuFqOOEtO;$&.*ZB\"]]<29ROB##[[VP CtuVXOOuvOEOu,'[O! #[YWPLBVvSw%"
"?\"8:&&;sKpB2]=Jvv[OuqX[OO##[WSPOBVvSw!?*8ROFAA/* psN =V<J>RO+!%[suV wMvVXO["
"uv?""?OU? [O2&#[s-+ Dsu+=J&BMOu#+YO/@![sV& O\"qVDS(I<BMsUI#RSR[:#EPLq>^_s#D/"
"\" ps@ uVLu^__v##;[@p[V#uX<LMsKQ$K.@EVV sOuvOtL-SAs!:;s#pKVCuPOY>^_sCW,@^V%u"
"(<LMsAS%K, XRVvSwULM^_OSP'[)#Q OuvVB!@SLq^__^-s/@[VV\\MtuV_O#YW$;[AsQ wCE uV"
"Lu^_/W<#;J#HKVCuPOMuO=ROKt;[s=2 [RK =JJsCt;B#B-^_.;u <LMsQs:K-@_V&=uJsHO^_%K"
",\" pCq'u(LY>^_sCP,@^V%uJFqOOUJ[K%:;sSQ[V uVLM-p[[O[##;u@Q CQpV^vuu&uEOEpE[%"
";/ XVVpUF/LY^'%KWBKRC=S?pXw!;[pAQ [SpV8Jtu.sNC^W%K,  AVwV@qvuvBDO-q#K%[/ [VV"
"NIuu&H[W>^_sWC- _V<=uJsM'^/:[\"  sVp>=uJsH/^_:;[[SP [vuV^Buuv[^OuPA[OS\\!/ X"
"V&uJvDuOu#-Q%K,@YVV@.Iuv[8OuM.[/w^#;OWS _[p:=uJsH_^?%;[[S) BJvVp/2Jv[tL=>X[O"
"Sp?[;2P BSF<u>L%^/:2;ssI";
