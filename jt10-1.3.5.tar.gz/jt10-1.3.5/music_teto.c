#define static 
#define z music_teto_Data 
#define Values music_teto 
int Values[]={242 /* size */, 224, /* rows */
	0 /* loop */, 250 /* xor */, 19, /* compr */
	5  /* depf */, 7 /* len */,
	64 /* count */, 140 /* roll */,
	300 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"w0Ij0a?uP:EJfTg1etmj3boNf:1Jvufaetlv3aoBFEEJVta1etbh3boN^:1"
"JFTmaetl@2aov09>JvWQ110w``oZv>aF1oAu3hIjl:=A91jQWoFk=hIjlB=Q91J9uSUetk:3M=QD"
"iWCGoWt80C3a]RdfGB1oW=tiIjnn2Y>aGGoWtj1o0a?Sv>>JfwV1v1I>mbw@>9>JfWQ110I2P:]R"
"dNfA1P1e0n:c`oZf9A@1SUetl83aoRi";
