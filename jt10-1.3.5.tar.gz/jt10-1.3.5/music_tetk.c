#define static 
#define z music_tetk_Data 
#define Values music_tetk 
int Values[]={939 /* size */, 2638, /* rows */
	78 /* loop */, 105 /* xor */, 0, /* compr */
	11  /* depf */, 8 /* len */,
	64 /* count */, 3 /* roll */,
	272 /* tempo */
};typedef unsigned char by;
/* This source was optimized with Findbest of the Bisqwit's Midtools pack */
static by*z=(by*)"m(mnj\\|SJXcIKTHQyGWczjrljujfjnodzSyJrjsj~lBmZHnaJy|`j@jAjj"
"BbxJ_ngj~fomb]JoJIO|jj~[mjRqfJL@{jPyCmjJ({jjT+jjHLljJ({jjT+j\\SJnR{Z+BC}{O(m"
"nj|t^oJjJljDlyRUmzjrm{+jljfjb`FjJoMojZjOjrfNmj]zosHjnjpR\\{JjjowHjnjpr_{Jjjo"
"vHjnj~J_{JjjojZjgjboRz@cjmja\\VobjZjjfZlj\\jxjRMNmjfZbjjdxjBmNmjao{jLg@jz]~a"
"Jno`j~fC^UmzjzMx+jljfjjoFjJfJoj~f]jZ`]jj`zqw(SVoj\177MmjrqoCHjnj|R^+EKj]jHjF"
"[vjJqZLy+w(m)jbjFjBKjmj`jNm\\jZQzljpmejzf~jjARmjxNfj~fFlzozejj^+mjz+cjj)Kjj^"
"+mjz+cZaXJj+jlj+ojJnrFujmjaL)obj^jjfjojdmgjrmZjJrJojvj+oBMr@GujmjZv)WTCPfJjZ"
"a^(mnjZjzfzFu_jljpfWKP[YujmJnF)wWcjozmw_P(Y)oBrVUFKjmJ+mjz~njj)Kjj^+mjz+cjja"
"Tj+jlj{Jwazjbmv+R(YYlbjVLYKw+_pmnj|rP+FKjrj`BYlbjBjYKt+j(j`nwyPtFQrG](O)+taz"
"jZLs+[(qYlbj~MDKq+jnoprwQP[YKjzmljzjfbPKFKjcl`jb`H}QDDKq+FpmnjDJQ{GKjyJ`vYlb"
"jNJGKs+jPofjJrZjj|JlXpI)WTcJ|JmjWMfjJmv}QDDKq+j~fWjb]rjja_cjxewjz]j`Jno`j~fy"
"jb]Zjjaoyj~pujzpYjJHqnjbjImzOujjlJn](O)oReQjjp`ojLmcmZsAmJHaoj~fwjBAQjjXJajF"
"lxjb(QjJLMwF(mnjrjj)~mjdj`jjz+cjj)Kjj^+mjz+cjj)Kjj^vj";
